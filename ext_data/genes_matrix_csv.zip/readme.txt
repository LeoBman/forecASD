==============================================
BrainSpan: Atlas of the Developing Human Brain
==============================================

This data set contains RNA-Seq RPKM (reads per kilobase per million; see the whitepaper at
www.brainspan.org) values averaged to genes.

expression_matrix.csv -- the rows are genes and the columns samples; the first column is the row number
rows_metadata.csv -- the genes are listed in the same order as the rows in expression_matrix.csv
columns_metadata.csv -- the samples are listed in the same order as the columns in expression_matrix
